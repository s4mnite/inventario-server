# Corrección: margen de huevos, gastos y costo de compra

## Archivos modificados
- `frontend/src/HuevosModule.jsx`
- `frontend/src/App.jsx`

## 1. Margen de huevos erróneo
En el bloque "Costo/Beneficio" de Reportes, el costo de cada venta se buscaba
solo en la lista de productos del inventario general. Los ítems de huevos no
son un "producto" con ese nombre, así que su costo siempre sumaba $0: el
ingreso de la venta de huevos sí se contaba, pero su costo no, inflando el
margen y la ganancia cada vez que se vendían huevos.

Ahora el costo de huevos se calcula igual que en el resto de la app, usando
el costo de compra (`costoCaja`) guardado en el propio ítem de la venta al
momento de venderse — nunca el precio de venta.

## 2. Gastos debe incluir huevos
Comprar huevos (registrar una "entrada" en el módulo Huevos) nunca generaba
un gasto: Huevos y Gastos son colecciones separadas y no había ningún puente
entre ellas. La categoría "Huevos" ya existía en el módulo Gastos (y el
resumen "Mercadería" ya la esperaba), pero nunca se completaba sola.

Ahora, cada vez que se registra una entrada de huevos, además de guardar el
movimiento se crea automáticamente un gasto en categoría "huevos". Si el
registro del gasto falla, la entrada ya guardada no se revierte: se avisa
para agregarlo manualmente.

## 3. El monto no debe salir de lo que se vende, sino de lo que se compra
El gasto que se crea automáticamente usa siempre `purchaseTotal`
(cantidad comprada × costo por unidad de compra configurado para esa
calidad), calculado en el momento de la compra. No depende de ningún precio
o monto de venta.

## 4. Al registrar un gasto con "Manga / Bulto" se usaba el precio de venta
Al elegir un producto con manga/bulto activo (por ejemplo "Elite") y usar el
modo "Manga / Bulto" para registrar la compra, el campo "Precio por manga" se
precargaba con `mangaPrecio`, que es el precio de VENTA del bulto al cliente
(el mismo que se usa en el punto de venta) — no lo que se pagó al comprarlo.
Si el usuario no lo cambiaba, el gasto quedaba registrado con ese precio de
venta (ej. $18.500) en vez del precio de compra, y además ese número
alimentaba el costo promedio del producto (`/api/gastos` actualiza `costo`
con un promedio ponderado), dejando mal calculado el costo del producto
hacia adelante.

Ahora ese campo parte de una estimación basada en el costo de compra actual
del producto (costo unitario × unidades por manga) — nunca del precio de
venta — y el usuario la ajusta si el monto realmente pagado en esa compra es
distinto. Además se muestra, solo como referencia y aclarado como tal, el
precio de venta de la manga para que no se confunda con el de compra.

### Archivo modificado
- `frontend/src/GastosModule.jsx`

## No modificado
- MongoDB, caja, autenticación
- Flujo de venta de huevos y productos
- Stock y lotes de huevos
